import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots

def render(benchmarks, evaluations):
    st.markdown('<div id="benchmarks" class="section-anchor"></div>', unsafe_allow_html=True)
    st.header("Benchmarks")
    col1, col2 = st.columns(2)
    with col1:
        modality = st.selectbox("Modality", options=["All", "Multimodal", "Text-Only", "Both"])
    with col2:
        categories = st.multiselect("Categories", options=["Pwn", "Web", "Crypto", "Forensics"])

    filtered = benchmarks
    if modality != "All":
        filtered = filtered[filtered['modality'] == modality]
    if categories:
        filtered = filtered[filtered['categories'].apply(lambda cats: any(cat in categories for cat in cats))]

    # Cards
    for _, bench in filtered.iterrows():
        col1, col2, col3 = st.columns([3, 1, 1])
        with col1:
            st.write(f"**{bench['name']}**")
            st.write(f"Categories: {', '.join(bench['categories'])}")
        with col2:
            st.write(f"Modality: {bench['modality']}")
        with col3:
            st.metric("Avg Solve", f"{bench['avgSolve']}%")
        if st.button(f"View Details {bench['name']}", key=f"detail_{bench['id']}", use_container_width=True):
            selected_bench_id = bench['id']
            selected_bench_name = bench['name']
            st.title(f"Benchmark Details: {selected_bench_name}")
            # Chart
            evals = evaluations[evaluations['benchmarkId'] == selected_bench_id]
            fig = make_subplots(specs=[[{"secondary_y": True}]])
            fig.add_trace(go.Scatter(x=evals['date'], y=evals['solveRate'], name='Solve Rate'), secondary_y=False)
            fig.add_trace(go.Scatter(x=evals['date'], y=evals['visionAccuracy'], name='Vision Accuracy'), secondary_y=True)
            st.plotly_chart(fig)
            st.dataframe(evals, use_container_width=True)
