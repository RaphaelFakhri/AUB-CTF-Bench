import streamlit as st

def render(team):
    st.markdown('<div id="about" class="section-anchor"></div>', unsafe_allow_html=True)
    st.header("About the Team")
    col1, col2, col3 = st.columns(3)
    for i, person in enumerate(team):
        with locals()[f"col{i+1}"]:
            st.write(f"**{person['name']}**")
            st.write(person['role'])
            st.write(person['bio'])
