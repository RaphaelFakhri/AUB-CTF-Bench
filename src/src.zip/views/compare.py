import streamlit as st
import pandas as pd
import plotly.express as px
import random

def render(models):
    st.markdown('<div id="compare" class="section-anchor"></div>', unsafe_allow_html=True)
    st.header("Compare Models")
    col1, col2 = st.columns(2)
    with col1:
        model1 = st.selectbox("Model 1", options=[m['name'] for m in models.to_dict('records')])
    with col2:
        model2 = st.selectbox("Model 2", options=[m['name'] for m in models.to_dict('records')])
    if st.button("Compare", use_container_width=True):
        m1_data = models[models['name'] == model1]['solveRate'].iloc[0]
        m2_data = models[models['name'] == model2]['solveRate'].iloc[0]
        # Mock comparison data
        comp_data = pd.DataFrame({
            'Benchmark': ['Bench1', 'Bench2', 'Bench3'],
            f'{model1} Solve': [random.uniform(70, 90) for _ in range(3)],
            f'{model2} Solve': [random.uniform(65, 85) for _ in range(3)],
        })
        fig = px.line(comp_data, x='Benchmark', y=[f'{model1} Solve', f'{model2} Solve'], title=f"Comparison: {model1} vs {model2}")
        st.plotly_chart(fig)
        st.dataframe(comp_data, use_container_width=True)

        # Summary
        winner = model1 if m1_data > m2_data else model2
        st.success(f"Overall Winner: {winner}")
