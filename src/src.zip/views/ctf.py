import streamlit as st

def render(ctf_challenges):
    st.markdown('<div id="ctf" class="section-anchor"></div>', unsafe_allow_html=True)
    st.header("CTF Challenges")
    st.dataframe(ctf_challenges, use_container_width=True)
    selected_ctf = st.selectbox("Select CTF to Analyze", options=ctf_challenges['name'].tolist())
    if st.button("Analyze", use_container_width=True):
        ctf = ctf_challenges[ctf_challenges['name'] == selected_ctf].iloc[0]
        solved = "Yes" if ctf['hasImage'] else "Partial"
        st.success(f"Analyzed {selected_ctf}: Solved - {solved} (Vision used: {ctf['hasImage']})")
    if st.button("Add New CTF", use_container_width=True):
        st.success("New CTF form opened")
