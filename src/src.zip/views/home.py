import streamlit as st
from src.utils import get_image_as_base64
def render(models): # The function signature must match the call in main.py
    st.markdown('<div id="home" class="section-anchor"></div>', unsafe_allow_html=True)

    logo = get_image_as_base64("assets/logo.png")
    # Apply max-width directly to the image using markdown
    st.markdown(f"""
    <div style="text-align: center;">
        <img src="data:image/png;base64,{logo}" alt="Logo" style="max-width: 12%; height: auto; margin: 0 auto;">
    </div>
    """, unsafe_allow_html=True)

    # Combined Title
    st.markdown("""
    <h1 style="text-align: center; font-size: 2rem; font-weight: 700; margin-top: 20px;">
        AUB-CTF-Bench: Bridging the Vision Gap
    </h1>
    """, unsafe_allow_html=True)

    # Subtitle
    st.markdown("""
    <p style="text-align: center; font-size: 1.2rem; color: #888;">
        Benchmarking Large Language Models on Multi-Modal Capture The Flag Problems
    </p>
    """, unsafe_allow_html=True)


