import streamlit as st

def render():
    st.markdown('<div id="thesis" class="section-anchor"></div>', unsafe_allow_html=True)
    st.header("Thesis Overview")
    st.markdown("Mock thesis on multi-modal CTF benchmarking.")
    # Mock PDF
    st.image("https://via.placeholder.com/800x600?text=Thesis+PDF", caption="Thesis PDF Preview", use_container_width=True)
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Download ZIP", use_container_width=True):
            st.success("Downloaded: Thesis Sections ZIP")
    with col2:
        if st.button("BibTeX", use_container_width=True):
            st.success("Copied BibTeX Citation")
