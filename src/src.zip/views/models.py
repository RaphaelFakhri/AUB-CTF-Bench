import streamlit as st

def render(models):
    st.markdown('<div id="models" class="section-anchor"></div>', unsafe_allow_html=True)
    st.header("Models Leaderboard")
    col1, col2 = st.columns(2)
    with col1:
        provider = st.selectbox("Filter Provider", options=["All"] + sorted(models['provider'].unique().tolist()))
    with col2:
        category = st.selectbox("Filter Category", options=["All"] + sorted(models['category'].unique().tolist()))

    filtered = models
    if provider != "All":
        filtered = filtered[filtered['provider'] == provider]
    if category != "All":
        filtered = filtered[filtered['category'] == category]

    st.dataframe(filtered[['name', 'provider', 'context', 'input1M', 'output1M', 'throughput', 'latency', 'solveRate', 'visionAccuracy', 'qualityScore']], use_container_width=True, hide_index=True)

    # Actions
    selected = st.multiselect("Select Models for Actions", options=filtered['name'].tolist())
    if st.button("Run CTF on Selected", use_container_width=True):
        for m in selected:
            st.success(f"Running CTF on {m}")
    if selected:
        if st.button("View Stats", use_container_width=True):
            for m in selected:
                st.info(f"Mock stats for {m}: High performance in vision tasks.")
