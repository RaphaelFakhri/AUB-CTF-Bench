# ruff: noqa: F401
import pandas as pd
import random
import streamlit as st

@st.cache_data
def load_mock_data():
    models = pd.DataFrame([
        {'id': 1, 'name': 'GPT-4V', 'provider': 'OpenAI', 'logo': '🟦', 'context': '128K', 'input1M': '$0.01 / 2s', 'output1M': '$0.03 / 5s', 'throughput': '150 t/s', 'latency': '1.2s', 'category': 'Vision', 'solveRate': 85, 'visionAccuracy': 92, 'co2Cost': 'Low', 'qualityScore': 9.2},
        {'id': 2, 'name': 'Claude-3 Opus', 'provider': 'Anthropic', 'logo': '🟣', 'context': '200K', 'input1M': '$0.015 / 3s', 'output1M': '$0.075 / 8s', 'throughput': '120 t/s', 'latency': '1.5s', 'category': 'General', 'solveRate': 78, 'visionAccuracy': 88, 'co2Cost': 'Medium', 'qualityScore': 8.8},
        {'id': 3, 'name': 'Llama-3 70B', 'provider': 'Meta', 'logo': '🟢', 'context': '8K', 'input1M': '$0.005 / 4s', 'output1M': '$0.015 / 10s', 'throughput': '80 t/s', 'latency': '2.0s', 'category': 'Open', 'solveRate': 72, 'visionAccuracy': 75, 'co2Cost': 'High', 'qualityScore': 8.0},
        {'id': 4, 'name': 'Gemini 1.5', 'provider': 'Google', 'logo': '🔴', 'context': '1M', 'input1M': '$0.008 / 1.5s', 'output1M': '$0.025 / 4s', 'throughput': '200 t/s', 'latency': '1.0s', 'category': 'Vision', 'solveRate': 82, 'visionAccuracy': 90, 'co2Cost': 'Low', 'qualityScore': 9.0},
        {'id': 5, 'name': 'Mistral Large', 'provider': 'Mistral', 'logo': '🟠', 'context': '32K', 'input1M': '$0.01 / 3s', 'output1M': '$0.03 / 7s', 'throughput': '100 t/s', 'latency': '1.8s', 'category': 'General', 'solveRate': 70, 'visionAccuracy': 80, 'co2Cost': 'Medium', 'qualityScore': 7.8},
    ])

    benchmarks = pd.DataFrame([
        {'id': 1, 'name': 'Google CTF 2023', 'categories': ['Web', 'Pwn'], 'modality': 'Multimodal', 'created': 15, 'evaluations': 42, 'avgSolve': 78},
        {'id': 2, 'name': 'PicoCTF Images', 'categories': ['Crypto', 'Web'], 'modality': 'Multimodal', 'created': 10, 'evaluations': 25, 'avgSolve': 65},
        {'id': 3, 'name': 'AUB Custom Pwn Set', 'categories': ['Pwn'], 'modality': 'Text-Only', 'created': 12, 'evaluations': 30, 'avgSolve': 72},
        {'id': 4, 'name': 'HackTheBox Vision', 'categories': ['Pwn', 'Forensics'], 'modality': 'Both', 'created': 8, 'evaluations': 35, 'avgSolve': 80},
        {'id': 5, 'name': 'Crypto Text Only', 'categories': ['Crypto'], 'modality': 'Text-Only', 'created': 20, 'evaluations': 28, 'avgSolve': 75},
    ])

    evaluations = pd.DataFrame([
        {'id': 1, 'benchmarkId': 1, 'modelId': 1, 'date': '2024-01-15', 'solveRate': 85, 'visionAccuracy': 92, 'turnsAvg': 5, 'tokensAvg': 1200},
        {'id': 2, 'benchmarkId': 1, 'modelId': 2, 'date': '2024-01-16', 'solveRate': 78, 'visionAccuracy': 88, 'turnsAvg': 6, 'tokensAvg': 1500},
    ])

    runs = pd.DataFrame([
        {'id': 1, 'evaluationId': 1, 'ctfName': 'Web Challenge 1', 'category': 'Web', 'modality': 'Multimodal', 'solved': True, 'turns': 3, 'tokens': 800, 'visionUsed': 95},
        {'id': 2, 'evaluationId': 1, 'ctfName': 'Pwn Challenge 2', 'category': 'Pwn', 'modality': 'Text-Only', 'solved': False, 'turns': 7, 'tokens': 2000, 'visionUsed': None},
    ])

    ctf_challenges = pd.DataFrame([
        {'name': 'Web Vuln 1', 'category': 'Web', 'difficulty': 'Easy', 'hasImage': True},
        {'name': 'Pwn Buffer', 'category': 'Pwn', 'difficulty': 'Medium', 'hasImage': False},
        {'name': 'Crypto RSA', 'category': 'Crypto', 'difficulty': 'Hard', 'hasImage': True},
    ])

    team = [
        {'name': 'Raphael Fakhri', 'role': 'Lead Developer', 'bio': 'PhD candidate focusing on multi-modal LLM benchmarking for CTF.'},
        {'name': 'Prof. Haidar Safa', 'role': 'Advisor', 'bio': 'Expert in cybersecurity and AI applications.'},
        {'name': 'Prof. Mohammad Nassar', 'role': 'Co-Advisor', 'bio': 'Specialist in machine learning and ethical AI.'},
    ]

    return models, benchmarks, evaluations, runs, ctf_challenges, team
